<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="info_style.css">
		<title>Target Information</title>
	</head>

	<body style="background-color: rgb(255,204,153);">
		<div class = 'box'>	
		
			<div class = "imgBx">
				<img src="trgt1.png">
			</div>

			<div class= "content">
				<h2> Edgar Smith </h2>
				<p> Description: Boss of a Dirty organization in Ostiana </br>
					Age: 52 </br>
					Gender: Male </br>
					Location: Ostania, Germany </br>
					Goal: Determine the name of the Organization, purpose and exposed it to the police. </br>
				 </p>
			</div>

		</div>

		<div class = 'box2'>	
		
			<div class = "imgBx">
				<img src="trgt2.png">
			</div>

			<div class= "content">
				<h2> Nyugen Becker </h2>
				<p> Description: Underling of Edgar </br>
					Age: 40 </br>
					Gender: Male </br>
					Location: Ostania, Germany </br>
					Goal: Kidnap him and Make him spill their organization. </br> 
				</p>
			</div>

		</div>

		<div class = 'box3'>	
		
			<div class = "imgBx">
				<img src="trgt3.png">
			</div>

			<div class= "content">
				<h2> Minister Brantz </h2>
				<p> Description: Foreign Minister of Westalis, Europe </br>
					Age: 45 </br>
					Gender: Male </br>
					Location: Westalis, Germany </br>
					Goal: Locate all documents that will prove that this man is a corrupt politician </br>
					</p>
			</div>

		</div>

		<div class = 'box4'>	
		
			<div class = "imgBx">
				<img src="trgt4.png">
			</div>

			<div class= "content">
				<h2> Cavi Campbell </h2>
				<p> Description: One of the most foremost collectors of classical art and one of the organizers in a underground tennis competion. </br>
					Age: 56 </br>
					Gender: Male </br>
					Location: Ostiana, Germany </br>
					Goal: Locate all documents of the smuggled collections and illegal earnings from the underground competition.</br>  
				</p>
			</div>

		</div>

		<div class = 'box5'>	
		
			<div class = "imgBx">
				<img src="trgt5.png">
			</div>

			<div class= "content">
				<h2> Kurt Stevens </h2>
				<p> Description: A member of Berlint Terrorist grouped by Keith Kepler  </br>
					Age: 35 </br>
					Gender: Male </br>
					Location: Unknown </br>
					Goal: Locate him and make him splii the location of their leader, Keith Kepler.</br> 
					 </p>
			</div>

		</div>
		
		<div class = 'box6'>	
		
			<div class = "imgBx">
				<img src="trgt6.png">
			</div>

			<div class= "content">
				<h2> Keith Kepler </h2>
				<p> Description: Leader of the famous terrorist group known as "Berlint Terrorist" </br>
					Age: 32 </br>
					Gender: Male </br>
					Location: Unknown </br>
					Goal: Locate him and alert the police to assist in catching this person and put a stop on the organization.</br>
				</p>
			</div>

		</div>

		<div class = 'box7'>	
		
			<div class = "imgBx">
				<img src="trgt7.png">
			</div>

			<div class= "content">
				<h2> Rudy Williams </h2>
				<p> Description: A shookeper that provides target photos to a certain assassin. </br>
					Age: 38 </br>
					Gender: Male </br>
					Location: westalis, Germany </br>
					Goal: Find some document that will prove that this person is associated into some dirty organization that works underground. </br> 
				</p>
			</div>

		</div>

		<div class = 'box8'>	
		
			<div class = "imgBx">
				<img src="trgt8.png">
			</div>

			<div class= "content">
				<h2> Eric Zacharis </h2>
				<p> Description: A colonel in East Military Interligence Division </br>
					Age: 61 </br>
					Gender: Male </br>
					Location: Unknown </br>
					Goal: Find some document regarding to that this person is leaking  information of the country's miitary force to another country.</br>
					 </p>
			</div>

		</div>

		<center> <a href="content.php"> << Back to the Poster Page </a> </center>
		<center> <a href="index.php?logout='1'" style="color: red;">logout</a> </center>

	</body>
</html>