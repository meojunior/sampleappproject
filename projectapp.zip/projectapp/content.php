<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="stylesheet" href="cont_style.css">

	<title>Spy Association</title>
</head>

<body style="background-color: rgb(255,204,153);">
	<h1>TARGET LIST</h1>

	<br>

	<div class="container">
		<div class="image-container">
			<div class="image"><img src="trgt1.png" alt=""></div>
			<div class="image"><img src="trgt2.png" alt=""></div>
			<div class="image"><img src="trgt3.png" alt=""></div>
			<div class="image"><img src="trgt4.png" alt=""></div>
			<div class="image"><img src="trgt5.png" alt=""></div>
			<div class="image"><img src="trgt6.png" alt=""></div>
			<div class="image"><img src="trgt7.png" alt=""></div>
			<div class="image"><img src="trgt8.png" alt=""></div>	
		</div>

		<div class="popup-image">
			<span>&times;</span>
			<img src="trgt1.png" alt="">
		</div>
		
	</div>


<script> //for pop-up image on the top
	document.querySelectorAll('.image-container img').forEach(image =>{
		image.onclick = () =>{
			document.querySelector('.popup-image').style.display = 'block';
			document.querySelector('.popup-image img').src = image.getAttribute('src');
		}
	});

	document.querySelector('.popup-image span').onclick = () =>{
		document.querySelector('.popup-image').style.display = 'none';
	}

</script>


 <center> <a href="information.php"> For the Target Information >> </a> </center>

</body>
</html>